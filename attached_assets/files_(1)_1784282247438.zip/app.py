"""
app.py
-----------------------------------------------------------------------------
Main entry point for the Discord Bot Dashboard (Flask application).

Responsibilities:
    - Application factory (create_app) that wires up config + blueprints
    - Session-based authentication guarding the dashboard pages
    - HTML page routes (render_template views)
    - Blueprint registration for the JSON REST API (api/*.py)

Run locally with:
    python app.py

Run in production with a WSGI server, e.g.:
    gunicorn "app:create_app()"
-----------------------------------------------------------------------------
"""

import os
from functools import wraps

from flask import Flask, render_template, redirect, url_for, session, request, flash, jsonify

from config import config_by_name
from api.stats import stats_bp
from api.blacklist import blacklist_bp
from api.tickets import tickets_bp
from api.giveaways import giveaways_bp
from api.logs import logs_bp
from api.settings import settings_bp


def create_app(config_name=None):
    """Application factory — builds and configures the Flask app instance."""

    app = Flask(__name__)

    # ---------------------------------------------------------------
    # Configuration
    # ---------------------------------------------------------------
    config_name = config_name or os.environ.get("FLASK_ENV", "default")
    app.config.from_object(config_by_name.get(config_name, config_by_name["default"]))

    # ---------------------------------------------------------------
    # Blueprint registration (all JSON REST endpoints)
    # ---------------------------------------------------------------
    app.register_blueprint(stats_bp)
    app.register_blueprint(blacklist_bp)
    app.register_blueprint(tickets_bp)
    app.register_blueprint(giveaways_bp)
    app.register_blueprint(logs_bp)
    app.register_blueprint(settings_bp)

    # ---------------------------------------------------------------
    # Authentication helpers
    # ---------------------------------------------------------------
    def login_required(view_func):
        """Redirect unauthenticated users to /login before serving a page."""
        @wraps(view_func)
        def wrapped(*args, **kwargs):
            if not session.get("logged_in"):
                return redirect(url_for("login", next=request.path))
            return view_func(*args, **kwargs)
        return wrapped

    # Shared template context: injected into every rendered page so the
    # sidebar/footer/nav partials always have bot branding available.
    @app.context_processor
    def inject_global_context():
        return {
            "bot_name": app.config.get("BOT_NAME"),
            "bot_version": app.config.get("BOT_VERSION"),
            "developer_name": app.config.get("DEVELOPER_NAME"),
            "github_repo_url": app.config.get("GITHUB_REPO_URL"),
            "support_server_url": app.config.get("SUPPORT_SERVER_URL"),
        }

    # ---------------------------------------------------------------
    # Auth routes
    # ---------------------------------------------------------------
    @app.route("/login", methods=["GET", "POST"])
    def login():
        """Simple username/password login for the dashboard admin panel.

        TODO (integration): swap for Discord OAuth2 using
        config.DISCORD_CLIENT_ID / DISCORD_CLIENT_SECRET so staff log in
        with their actual Discord account and permissions are checked
        against real guild roles.
        """
        if session.get("logged_in"):
            return redirect(url_for("index"))

        if request.method == "POST":
            username = request.form.get("username", "")
            password = request.form.get("password", "")

            if (username == app.config["DASHBOARD_USERNAME"]
                    and password == app.config["DASHBOARD_PASSWORD"]):
                session["logged_in"] = True
                session["username"] = username
                session.permanent = True
                flash("Welcome back! You have been logged in successfully.", "success")
                next_page = request.args.get("next") or url_for("index")
                return redirect(next_page)

            flash("Invalid username or password. Please try again.", "danger")

        return render_template("login.html")

    @app.route("/logout")
    def logout():
        session.clear()
        flash("You have been logged out.", "info")
        return redirect(url_for("login"))

    # ---------------------------------------------------------------
    # Dashboard page routes (HTML views)
    # ---------------------------------------------------------------
    @app.route("/")
    @login_required
    def index():
        """Dashboard Home — overview cards, charts, service status."""
        return render_template("index.html", active_page="dashboard")

    @app.route("/settings")
    @login_required
    def settings_page():
        """Bot configuration page (prefix, embed color, welcome, etc.)."""
        return render_template("settings.html", active_page="settings")

    @app.route("/blacklist")
    @login_required
    def blacklist_page():
        """Blacklist management page (add/remove/search users)."""
        return render_template("blacklist.html", active_page="blacklist")

    @app.route("/tickets")
    @login_required
    def tickets_page():
        """Support ticket management page."""
        return render_template("tickets.html", active_page="tickets")

    @app.route("/giveaways")
    @login_required
    def giveaways_page():
        """Giveaway management page."""
        return render_template("giveaways.html", active_page="giveaways")

    @app.route("/logs")
    @login_required
    def logs_page():
        """Log viewer page (server / moderation / error / bot logs)."""
        return render_template("logs.html", active_page="logs")

    # ---------------------------------------------------------------
    # Error handlers
    # ---------------------------------------------------------------
    @app.errorhandler(404)
    def not_found(error):
        if request.path.startswith("/api/"):
            return jsonify({"error": "Endpoint not found"}), 404
        return render_template("login.html", error_message="Page not found."), 404

    @app.errorhandler(500)
    def server_error(error):
        if request.path.startswith("/api/"):
            return jsonify({"error": "Internal server error"}), 500
        return render_template("login.html", error_message="Something went wrong."), 500

    return app


# Module-level app instance so `flask run` / gunicorn can import "app:app"
app = create_app()


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=app.config.get("DEBUG", False))
