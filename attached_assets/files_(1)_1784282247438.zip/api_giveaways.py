"""
api/giveaways.py
-----------------------------------------------------------------------------
REST API blueprint for the Giveaways page: list running/ended giveaways,
reroll a winner, and force-end a giveaway.

TODO (integration): connect GiveawayStore to the collection your giveaway
cog uses (entrants list, prize, channel/message id, end timestamp) and, for
reroll/end, trigger the bot to actually edit the Discord giveaway embed and
DM the new winner — typically via a shared MongoDB "pending_actions" queue
the bot polls, or a direct IPC call.
-----------------------------------------------------------------------------
"""

import random
from datetime import datetime, timedelta

from flask import Blueprint, jsonify, request

giveaways_bp = Blueprint("giveaways_api", __name__, url_prefix="/api/giveaways")


class GiveawayStore:
    """Placeholder giveaway data store — see module docstring for integration."""

    def __init__(self):
        now = datetime.utcnow()
        self._giveaways = [
            {
                "id": 501,
                "prize": "Discord Nitro (1 Month)",
                "host": "admin",
                "entrants": 342,
                "winners_count": 1,
                "status": "running",
                "ends_at": (now + timedelta(hours=6)).isoformat(),
                "created_at": (now - timedelta(days=1)).isoformat(),
                "winners": [],
            },
            {
                "id": 502,
                "prize": "Steam Game Key — Random AAA Title",
                "host": "staff_jane",
                "entrants": 187,
                "winners_count": 2,
                "status": "running",
                "ends_at": (now + timedelta(hours=20)).isoformat(),
                "created_at": (now - timedelta(hours=4)).isoformat(),
                "winners": [],
            },
            {
                "id": 503,
                "prize": "Custom Role + 5000 Server Currency",
                "host": "admin",
                "entrants": 96,
                "winners_count": 1,
                "status": "running",
                "ends_at": (now + timedelta(days=2)).isoformat(),
                "created_at": (now - timedelta(hours=12)).isoformat(),
                "winners": [],
            },
            {
                "id": 498,
                "prize": "$10 Amazon Gift Card",
                "host": "admin",
                "entrants": 421,
                "winners_count": 1,
                "status": "ended",
                "ends_at": (now - timedelta(days=1)).isoformat(),
                "created_at": (now - timedelta(days=3)).isoformat(),
                "winners": ["giftlover88"],
            },
            {
                "id": 495,
                "prize": "Server Booster Perks (1 Month)",
                "host": "staff_alex",
                "entrants": 210,
                "winners_count": 1,
                "status": "ended",
                "ends_at": (now - timedelta(days=5)).isoformat(),
                "created_at": (now - timedelta(days=8)).isoformat(),
                "winners": ["boosted_bella"],
            },
        ]

    def all(self):
        return sorted(self._giveaways, key=lambda g: g["created_at"], reverse=True)

    def by_status(self, status):
        return [g for g in self.all() if g["status"] == status]

    def get(self, giveaway_id):
        return next((g for g in self._giveaways if g["id"] == giveaway_id), None)

    def end(self, giveaway_id):
        giveaway = self.get(giveaway_id)
        if not giveaway:
            return None
        if giveaway["status"] == "running":
            giveaway["status"] = "ended"
            giveaway["ends_at"] = datetime.utcnow().isoformat()
            giveaway["winners"] = self._pick_winners(giveaway)
        return giveaway

    def reroll(self, giveaway_id):
        giveaway = self.get(giveaway_id)
        if not giveaway or giveaway["status"] != "ended":
            return None
        giveaway["winners"] = self._pick_winners(giveaway)
        return giveaway

    @staticmethod
    def _pick_winners(giveaway):
        # Placeholder winner names — a real implementation draws from the
        # actual reaction/entry list stored for the giveaway message.
        pool = ["lucky_user1", "winner_22", "giftwinnerxx", "raffle_king", "prize_hunter"]
        count = min(giveaway["winners_count"], len(pool))
        return random.sample(pool, count)


_store = GiveawayStore()


@giveaways_bp.route("", methods=["GET"])
def list_giveaways():
    """List giveaways, optionally filtered by status (running|ended)."""
    status = request.args.get("status", default="all", type=str)
    if status == "all":
        data = _store.all()
    elif status in ("running", "ended"):
        data = _store.by_status(status)
    else:
        return jsonify({"error": "status must be 'running', 'ended', or 'all'"}), 400

    return jsonify({
        "giveaways": data,
        "running_count": len(_store.by_status("running")),
        "ended_count": len(_store.by_status("ended")),
    })


@giveaways_bp.route("/<int:giveaway_id>/end", methods=["POST"])
def end_giveaway(giveaway_id):
    """Force-end a running giveaway and pick winners immediately."""
    giveaway = _store.end(giveaway_id)
    if not giveaway:
        return jsonify({"error": "Giveaway not found"}), 404
    return jsonify({"message": f"Giveaway #{giveaway_id} ended", "giveaway": giveaway})


@giveaways_bp.route("/<int:giveaway_id>/reroll", methods=["POST"])
def reroll_giveaway(giveaway_id):
    """Reroll winner(s) for an already-ended giveaway."""
    giveaway = _store.reroll(giveaway_id)
    if not giveaway:
        return jsonify({"error": "Giveaway not found or not yet ended"}), 404
    return jsonify({"message": f"Giveaway #{giveaway_id} rerolled", "giveaway": giveaway})
