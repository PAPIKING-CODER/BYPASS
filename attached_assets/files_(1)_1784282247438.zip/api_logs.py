"""
api/logs.py
-----------------------------------------------------------------------------
REST API blueprint for the Logs page: server logs, moderation logs, error
logs, and bot (system) logs.

TODO (integration): point LogStore at your actual logging destination —
most Discord.py bots either write structured logs to MongoDB (one document
per event) or to a rotating file handler. If using Python's `logging`
module with a RotatingFileHandler, tail the log file here instead of
returning the placeholder list.
-----------------------------------------------------------------------------
"""

from datetime import datetime, timedelta

from flask import Blueprint, jsonify, request

logs_bp = Blueprint("logs_api", __name__, url_prefix="/api/logs")

_LOG_CATEGORIES = ("server", "moderation", "error", "bot")


class LogStore:
    """Placeholder log data store — see module docstring for integration."""

    def __init__(self):
        now = datetime.utcnow()
        self._logs = [
            {"id": 1, "category": "server", "level": "info", "message": "New member joined: pixel_dreamer#0192", "timestamp": (now - timedelta(minutes=4)).isoformat()},
            {"id": 2, "category": "server", "level": "info", "message": "Channel #announcements created", "timestamp": (now - timedelta(hours=2)).isoformat()},
            {"id": 3, "category": "moderation", "level": "warning", "message": "User banned: raidbot_alpha (reason: mass mention spam)", "timestamp": (now - timedelta(minutes=20)).isoformat()},
            {"id": 4, "category": "moderation", "level": "info", "message": "User warned: chattycathy (reason: NSFW content in #general)", "timestamp": (now - timedelta(hours=1)).isoformat()},
            {"id": 5, "category": "moderation", "level": "warning", "message": "User muted: loudmouth99 for 30m (reason: spamming)", "timestamp": (now - timedelta(hours=3)).isoformat()},
            {"id": 6, "category": "error", "level": "error", "message": "Command '/play' failed: YouTube API rate limit exceeded", "timestamp": (now - timedelta(minutes=45)).isoformat()},
            {"id": 7, "category": "error", "level": "error", "message": "Database connection timeout on shard 2, retrying...", "timestamp": (now - timedelta(hours=5)).isoformat()},
            {"id": 8, "category": "bot", "level": "info", "message": "Bot reconnected to Discord Gateway (shard 0)", "timestamp": (now - timedelta(hours=6)).isoformat()},
            {"id": 9, "category": "bot", "level": "info", "message": "Cog 'Moderation' reloaded successfully", "timestamp": (now - timedelta(hours=8)).isoformat()},
            {"id": 10, "category": "bot", "level": "warning", "message": "Latency spike detected: 480ms", "timestamp": (now - timedelta(hours=10)).isoformat()},
        ]

    def all(self):
        return sorted(self._logs, key=lambda l: l["timestamp"], reverse=True)

    def by_category(self, category):
        return [l for l in self.all() if l["category"] == category]


_store = LogStore()


@logs_bp.route("", methods=["GET"])
def list_logs():
    """List logs, optionally filtered by category and paginated.

    Query params:
        category (str, optional): server | moderation | error | bot
        page (int, default 1)
        per_page (int, default 20)
    """
    category = request.args.get("category", default="all", type=str)
    page = request.args.get("page", default=1, type=int)
    per_page = request.args.get("per_page", default=20, type=int)

    if category == "all":
        data = _store.all()
    elif category in _LOG_CATEGORIES:
        data = _store.by_category(category)
    else:
        return jsonify({"error": f"category must be one of {_LOG_CATEGORIES} or 'all'"}), 400

    total = len(data)
    start = (page - 1) * per_page
    end = start + per_page

    counts = {cat: len(_store.by_category(cat)) for cat in _LOG_CATEGORIES}

    return jsonify({
        "logs": data[start:end],
        "page": page,
        "per_page": per_page,
        "total": total,
        "total_pages": max(1, (total + per_page - 1) // per_page),
        "counts": counts,
    })
