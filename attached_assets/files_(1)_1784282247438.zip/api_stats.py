"""
api/stats.py
-----------------------------------------------------------------------------
Core data-integration layer + REST API blueprint for the Discord Bot
Dashboard.

Two responsibilities live in this file:

1.  BotDataProvider
    A single class responsible for fetching *live* data from the running
    Discord bot process. Real bots typically expose this data one of three
    ways:
        a) A shared JSON "heartbeat" file the bot writes to periodically
           (BOT_STATS_FILE in config.py) — simplest, works across processes.
        b) A local IPC/TCP socket (discord.ext.ipc, aiohttp, etc.) that the
           dashboard queries on demand.
        c) A shared MongoDB collection both the bot and dashboard read/write.

    This class tries (a) first because it requires zero extra bot-side
    networking code, then falls back to safe, clearly-labelled placeholder
    data so the dashboard is fully functional (and demo-able) before the
    bot-side hook is wired up. Every placeholder function is documented with
    exactly what the real Discord.py implementation should return, so
    integration is a drop-in replacement.

2.  stats_bp (Flask Blueprint)
    All REST endpoints the frontend JavaScript (dashboard.js / charts.js)
    consumes. Every route returns JSON.
-----------------------------------------------------------------------------
"""

import json
import os
import platform
import random
import socket
import sys
import time
from datetime import datetime, timedelta

import psutil
from flask import Blueprint, jsonify, request, current_app

# -----------------------------------------------------------------------
# Blueprint registration
# -----------------------------------------------------------------------
stats_bp = Blueprint("stats_api", __name__, url_prefix="/api")

# Process start time, used to compute the *dashboard's* own uptime as a
# fallback if the bot process uptime isn't reachable.
_DASHBOARD_START_TIME = time.time()


# =========================================================================
# BotDataProvider
# =========================================================================
class BotDataProvider:
    """
    Reads live statistics from the running Discord bot process.

    Integration guide
    ------------------
    The recommended approach is for the bot process to periodically
    (every 5-10s) dump its live state to a small JSON file, e.g.:

        # inside your discord.py bot, in a @tasks.loop(seconds=5)
        import json
        def write_stats(bot):
            data = {
                "bot_name": bot.user.name,
                "bot_avatar": str(bot.user.display_avatar.url),
                "status": "online",
                "ping": round(bot.latency * 1000),
                "guild_count": len(bot.guilds),
                "member_count": sum(g.member_count for g in bot.guilds),
                "channel_count": sum(len(g.channels) for g in bot.guilds),
                "role_count": sum(len(g.roles) for g in bot.guilds),
                "commands_today": bot.commands_used_today,   # your own counter
                "discordpy_version": discord.__version__,
                "started_at": bot.start_time.isoformat(),
            }
            with open("bot_stats.json", "w") as f:
                json.dump(data, f)

    The dashboard (this class) reads that file on every API call. If the
    file is missing, stale (older than 30s), or malformed, we fall back to
    deterministic placeholder data so the UI never breaks.
    """

    STALE_AFTER_SECONDS = 30

    def __init__(self, app_config):
        self.config = app_config
        self.stats_file = app_config.get("BOT_STATS_FILE", "bot_stats.json")

    # ------------------------------------------------------------------
    # Low level file read
    # ------------------------------------------------------------------
    def _read_live_file(self):
        """Attempt to read the bot's live stats JSON file.

        Returns the parsed dict if the file exists, is valid JSON, and was
        written recently. Returns None otherwise (triggering placeholder
        fallback data upstream).
        """
        try:
            if not os.path.exists(self.stats_file):
                return None

            mtime = os.path.getmtime(self.stats_file)
            if (time.time() - mtime) > self.STALE_AFTER_SECONDS:
                # Data is too old to be trusted as "live"
                return None

            with open(self.stats_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return None

    def is_bot_connected(self):
        """True if we have a fresh live-data file from the bot process."""
        return self._read_live_file() is not None

    # ------------------------------------------------------------------
    # Bot identity / connection status
    # ------------------------------------------------------------------
    def get_bot_info(self):
        """Bot Name, Avatar, Status, Ping, Uptime, Version info."""
        live = self._read_live_file()

        if live:
            return {
                "name": live.get("bot_name", self.config.get("BOT_NAME")),
                "avatar_url": live.get("bot_avatar", self.config.get("BOT_AVATAR_URL")),
                "status": live.get("status", "online"),
                "ping": live.get("ping", 0),
                "uptime": self._format_uptime(live.get("started_at")),
                "bot_version": live.get("bot_version", self.config.get("BOT_VERSION")),
                "discordpy_version": live.get("discordpy_version", "2.4.0"),
                "connected": True,
            }

        # ---- Placeholder fallback (bot not connected yet) ----
        return {
            "name": self.config.get("BOT_NAME"),
            "avatar_url": self.config.get("BOT_AVATAR_URL"),
            "status": "offline",
            "ping": 0,
            "uptime": self._format_uptime(None),
            "bot_version": self.config.get("BOT_VERSION"),
            "discordpy_version": "2.4.0",
            "connected": False,
        }

    @staticmethod
    def _format_uptime(started_at_iso):
        """Convert an ISO start timestamp into a human readable duration."""
        if not started_at_iso:
            # Fallback: report how long the dashboard process itself has run
            delta = timedelta(seconds=int(time.time() - _DASHBOARD_START_TIME))
        else:
            try:
                started = datetime.fromisoformat(started_at_iso)
                delta = datetime.utcnow() - started
            except (ValueError, TypeError):
                delta = timedelta(seconds=int(time.time() - _DASHBOARD_START_TIME))

        days, remainder = divmod(int(delta.total_seconds()), 86400)
        hours, remainder = divmod(remainder, 3600)
        minutes, seconds = divmod(remainder, 60)

        parts = []
        if days:
            parts.append(f"{days}d")
        if hours or days:
            parts.append(f"{hours}h")
        parts.append(f"{minutes}m")
        parts.append(f"{seconds}s")
        return " ".join(parts)

    # ------------------------------------------------------------------
    # System resource metrics (these ARE always live — read straight from
    # the host machine running the dashboard/bot via psutil)
    # ------------------------------------------------------------------
    def get_system_info(self):
        """CPU / RAM / Disk usage + OS + Python version. Always live."""
        cpu_percent = psutil.cpu_percent(interval=0.2)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage("/")

        return {
            "cpu_percent": cpu_percent,
            "ram_percent": memory.percent,
            "ram_used_gb": round(memory.used / (1024 ** 3), 2),
            "ram_total_gb": round(memory.total / (1024 ** 3), 2),
            "disk_percent": disk.percent,
            "disk_used_gb": round(disk.used / (1024 ** 3), 2),
            "disk_total_gb": round(disk.total / (1024 ** 3), 2),
            "python_version": platform.python_version(),
            "os": f"{platform.system()} {platform.release()}",
            "hostname": socket.gethostname(),
        }

    # ------------------------------------------------------------------
    # Guild / member / channel / role counters
    # ------------------------------------------------------------------
    def get_guild_stats(self):
        """Total Servers, Members, Channels, Roles, Commands used today."""
        live = self._read_live_file()

        if live:
            return {
                "guild_count": live.get("guild_count", 0),
                "member_count": live.get("member_count", 0),
                "channel_count": live.get("channel_count", 0),
                "role_count": live.get("role_count", 0),
                "commands_today": live.get("commands_today", 0),
                "source": "live",
            }

        # ---- Placeholder fallback ----
        # Deterministic (not random-per-request) so the UI stays stable
        # between polling intervals until the real bot hook is connected.
        return {
            "guild_count": 128,
            "member_count": 48213,
            "channel_count": 954,
            "role_count": 612,
            "commands_today": 1734,
            "source": "placeholder",
        }

    # ------------------------------------------------------------------
    # Moderation / feature counters
    # ------------------------------------------------------------------
    def get_feature_counters(self):
        """Tickets open/closed, active giveaways, warnings, blacklist count.

        TODO (integration): replace with real queries against your MongoDB
        collections, e.g.:
            db.tickets.count_documents({"status": "open"})
            db.giveaways.count_documents({"active": True})
            db.warnings.count_documents({})
            db.blacklist.count_documents({})
        """
        live = self._read_live_file()
        if live and "feature_counters" in live:
            return live["feature_counters"]

        return {
            "tickets_open": 7,
            "tickets_closed": 132,
            "giveaways_active": 3,
            "warnings_total": 58,
            "blacklist_count": 14,
        }

    # ------------------------------------------------------------------
    # External service health checks
    # ------------------------------------------------------------------
    def get_service_status(self):
        """API / MongoDB / GitHub / UptimeRobot connectivity status.

        Each check is best-effort and non-blocking (short timeouts) so a
        slow/unreachable service never hangs the dashboard.
        """
        return {
            "api": self._check_self_api(),
            "mongodb": self._check_mongodb(),
            "github": self._check_github(),
            "uptime_robot": self._check_uptime_robot(),
        }

    def _check_self_api(self):
        # The fact this code is executing means the Flask API is up.
        return {"status": "operational", "label": "Operational"}

    def _check_mongodb(self):
        """TODO (integration): use pymongo to ping the real deployment:
            from pymongo import MongoClient
            client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=2000)
            client.admin.command('ping')
        """
        try:
            import pymongo  # noqa: F401  (import check only)
            uri = self.config.get("MONGO_URI")
            if not uri:
                return {"status": "not_configured", "label": "Not Configured"}
            client = pymongo.MongoClient(uri, serverSelectionTimeoutMS=1500)
            client.admin.command("ping")
            return {"status": "operational", "label": "Operational"}
        except Exception:
            return {"status": "offline", "label": "Offline"}

    def _check_github(self):
        try:
            import requests
            resp = requests.get("https://www.githubstatus.com/api/v2/status.json", timeout=2)
            if resp.status_code == 200:
                indicator = resp.json().get("status", {}).get("indicator", "none")
                status = "operational" if indicator == "none" else "degraded"
                return {"status": status, "label": status.capitalize()}
        except Exception:
            pass
        return {"status": "unknown", "label": "Unknown"}

    def _check_uptime_robot(self):
        api_key = self.config.get("UPTIME_ROBOT_API_KEY")
        if not api_key:
            return {"status": "not_configured", "label": "Not Configured"}
        try:
            import requests
            resp = requests.post(
                "https://api.uptimerobot.com/v2/getMonitors",
                data={"api_key": api_key, "format": "json"},
                timeout=2,
            )
            if resp.status_code == 200 and resp.json().get("stat") == "ok":
                return {"status": "operational", "label": "Operational"}
        except Exception:
            pass
        return {"status": "offline", "label": "Offline"}

    # ------------------------------------------------------------------
    # Historical chart data (Members / Commands / Servers / CPU / RAM)
    # ------------------------------------------------------------------
    def get_chart_history(self, metric, points=14):
        """Returns time-series data for the requested chart metric.

        TODO (integration): back this with a real time-series store
        (MongoDB capped collection, InfluxDB, Redis sorted set, etc.) that
        the bot writes a snapshot to on an interval (e.g. hourly).
        Currently generates a smooth, deterministic pseudo-series seeded by
        the metric name so charts look stable across refreshes rather than
        jumping around randomly.
        """
        rng = random.Random(metric)  # deterministic seed per metric
        today = datetime.utcnow().date()
        labels = [(today - timedelta(days=i)).strftime("%b %d") for i in range(points - 1, -1, -1)]

        baselines = {
            "members": 46000,
            "commands": 1200,
            "servers": 110,
            "cpu": 35,
            "ram": 50,
        }
        base = baselines.get(metric, 100)
        values = []
        current = base
        for _ in range(points):
            drift = rng.uniform(-0.03, 0.05) if metric in ("members", "servers") else rng.uniform(-0.15, 0.15)
            current = max(0, current * (1 + drift))
            values.append(round(current, 1))

        return {"labels": labels, "values": values}


def get_provider():
    """Factory returning a BotDataProvider bound to the current app config."""
    return BotDataProvider(current_app.config)


# =========================================================================
# REST API ROUTES
# =========================================================================

@stats_bp.route("/overview", methods=["GET"])
def overview():
    """Aggregate payload for the Dashboard Home page (single round trip)."""
    provider = get_provider()
    return jsonify({
        "bot": provider.get_bot_info(),
        "system": provider.get_system_info(),
        "guild": provider.get_guild_stats(),
        "features": provider.get_feature_counters(),
        "services": provider.get_service_status(),
        "timestamp": datetime.utcnow().isoformat(),
    })


@stats_bp.route("/bot", methods=["GET"])
def bot_info():
    """Bot name, avatar, status, ping, uptime, versions."""
    return jsonify(get_provider().get_bot_info())


@stats_bp.route("/system", methods=["GET"])
def system_info():
    """CPU / RAM / Disk / OS / Python version — always live via psutil."""
    return jsonify(get_provider().get_system_info())


@stats_bp.route("/guild", methods=["GET"])
def guild_stats():
    """Servers / members / channels / roles / commands used today."""
    return jsonify(get_provider().get_guild_stats())


@stats_bp.route("/features", methods=["GET"])
def feature_counters():
    """Tickets, giveaways, warnings, blacklist counters."""
    return jsonify(get_provider().get_feature_counters())


@stats_bp.route("/services", methods=["GET"])
def service_status():
    """API / MongoDB / GitHub / UptimeRobot status indicators."""
    return jsonify(get_provider().get_service_status())


@stats_bp.route("/chart/<metric>", methods=["GET"])
def chart_history(metric):
    """Time-series data for a given chart metric.

    Valid metrics: members, commands, servers, cpu, ram
    Query params:
        points (int, optional): number of data points to return (default 14)
    """
    valid_metrics = {"members", "commands", "servers", "cpu", "ram"}
    if metric not in valid_metrics:
        return jsonify({"error": f"Unknown metric '{metric}'. Valid: {sorted(valid_metrics)}"}), 400

    points = request.args.get("points", default=14, type=int)
    points = max(2, min(points, 90))  # clamp to a sane range
    return jsonify(get_provider().get_chart_history(metric, points))


@stats_bp.route("/ping", methods=["GET"])
def ping():
    """Lightweight healthcheck endpoint used by the frontend to confirm the
    API itself is reachable (distinct from the bot's own connection state).
    """
    return jsonify({"status": "ok", "time": datetime.utcnow().isoformat()})
