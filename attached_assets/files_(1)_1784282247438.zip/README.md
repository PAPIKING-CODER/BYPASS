# 🤖 Discord Bot Dashboard

A complete, production-ready web dashboard for a Discord.py bot — built with
**Flask**, **Bootstrap 5**, and **Chart.js**. Dark, Discord-inspired theme
with glassmorphism cards, blue/purple gradient accents, and full desktop /
tablet / mobile responsiveness.

![Python](https://img.shields.io/badge/Python-3.10%2B-blue)
![Flask](https://img.shields.io/badge/Flask-3.0-black)
![License](https://img.shields.io/badge/License-MIT-purple)

---

## ✨ Features

- **Dashboard Home** — bot identity card, live ping/uptime, CPU/RAM/Disk
  usage, server/member/channel/role counts, commands-used-today, tickets,
  giveaways, warnings, blacklist count, and external service status
  (API, MongoDB, GitHub, UptimeRobot).
- **Analytics charts** — Members Growth, Commands Usage, Servers Growth, and
  combined CPU/RAM usage, all powered by Chart.js.
- **Settings** — prefix, embed color, bot status/activity, welcome & leave
  messages, auto-role, and logging configuration.
- **Blacklist** — add / remove / search blacklisted users with pagination.
- **Tickets** — view open & closed tickets, claim, close, and view a full
  transcript.
- **Giveaways** — view running & ended giveaways, force-end, and reroll
  winners.
- **Logs** — server, moderation, error, and bot logs with category filters.
- Responsive sidebar navigation, toast notifications, animated loading
  screen, and a fully documented JSON REST API built with Flask Blueprints.

---

## 📂 Project Structure

```
website/
│
├── app.py                 # Flask app factory, page routes, auth
├── config.py               # Environment-driven configuration
├── requirements.txt
├── README.md
│
├── templates/
│   ├── base.html            # Shared layout (sidebar, topbar, footer)
│   ├── index.html           # Dashboard home
│   ├── login.html           # Auth page
│   ├── settings.html
│   ├── blacklist.html
│   ├── tickets.html
│   ├── giveaways.html
│   └── logs.html
│
├── static/
│   ├── css/
│   │   ├── style.css         # Design system + layout
│   │   └── animations.css    # Keyframes & motion utilities
│   ├── js/
│   │   ├── dashboard.js      # Core logic + all page controllers
│   │   └── charts.js         # Chart.js configuration
│   ├── images/                # favicon.png, bot-placeholder.png
│   └── icons/
│
└── api/
    ├── stats.py               # Bot data provider + overview/system routes
    ├── blacklist.py
    ├── tickets.py
    ├── giveaways.py
    ├── logs.py
    └── settings.py
```

---

## 🚀 Getting Started

### 1. Install dependencies

```bash
python -m venv venv
source venv/bin/activate       # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure environment variables

Create a `.env` file (or export these in your shell) — every value has a
sensible default, so this step is optional for a local demo:

```env
SECRET_KEY=super-secret-key
DASHBOARD_USERNAME=admin
DASHBOARD_PASSWORD=admin123

BOT_NAME=AtlasBot
BOT_VERSION=2.4.1
BOT_AVATAR_URL=https://cdn.discordapp.com/embed/avatars/0.png
BOT_INVITE_URL=https://discord.com/oauth2/authorize?client_id=YOUR_ID
SUPPORT_SERVER_URL=https://discord.gg/your-invite
GITHUB_REPO_URL=https://github.com/yourname/discord-bot
DEVELOPER_NAME=YourName

BOT_STATS_FILE=bot_stats.json
MONGO_URI=mongodb://localhost:27017
MONGO_DB_NAME=discord_bot

UPTIME_ROBOT_API_KEY=
```

### 3. Run the dashboard

```bash
python app.py
```

Visit **http://localhost:5000** and log in with the demo credentials
(`admin` / `admin123`, or whatever you set via `.env`).

### 4. Production deployment

```bash
gunicorn "app:create_app()" --bind 0.0.0.0:8000 --workers 4
```

---

## 🔌 Connecting Your Real Discord Bot

The dashboard is fully functional out of the box using clearly-labelled
placeholder data, so you can demo and style it immediately. To go live:

### Option A — Shared JSON heartbeat file (simplest)

In your `discord.py` bot, add a background task that writes a small JSON
snapshot every 5–10 seconds:

```python
import json
from discord.ext import tasks

@tasks.loop(seconds=5)
async def write_dashboard_stats():
    data = {
        "bot_name": bot.user.name,
        "bot_avatar": str(bot.user.display_avatar.url),
        "status": "online",
        "ping": round(bot.latency * 1000),
        "guild_count": len(bot.guilds),
        "member_count": sum(g.member_count for g in bot.guilds),
        "channel_count": sum(len(g.channels) for g in bot.guilds),
        "role_count": sum(len(g.roles) for g in bot.guilds),
        "commands_today": bot.commands_used_today,   # your own counter
        "discordpy_version": discord.__version__,
        "bot_version": "2.4.1",
        "started_at": bot.start_time.isoformat(),
    }
    with open("bot_stats.json", "w") as f:
        json.dump(data, f)
```

Point `BOT_STATS_FILE` in your `.env` at this same path (relative to where
the Flask app runs, or an absolute path if the bot and dashboard run in
different working directories). `api/stats.py`'s `BotDataProvider` will
automatically detect and read it.

### Option B — Shared MongoDB collection

Have both the bot and the dashboard read/write the same MongoDB database
(`MONGO_URI` / `MONGO_DB_NAME` in `config.py`). Replace the in-memory
`*Store` classes in `api/blacklist.py`, `api/tickets.py`,
`api/giveaways.py`, `api/logs.py`, and `api/settings.py` with `pymongo`
queries — each class is written so this is a drop-in swap, with the exact
query shape documented in the module docstring.

### Option C — Discord OAuth2 login

`config.py` already includes `DISCORD_CLIENT_ID` / `DISCORD_CLIENT_SECRET`
placeholders. Wire up the standard OAuth2 authorization-code flow in
`app.py`'s `/login` route to replace the simple username/password check
with real Discord account verification and guild-role permission checks.

---

## 🧩 REST API Reference

All endpoints return JSON and are organized into Flask Blueprints.

| Method | Endpoint                              | Description                          |
|--------|----------------------------------------|---------------------------------------|
| GET    | `/api/overview`                        | Aggregate payload for the home page   |
| GET    | `/api/bot`                             | Bot identity, status, ping, uptime    |
| GET    | `/api/system`                          | CPU / RAM / Disk / OS / Python info   |
| GET    | `/api/guild`                           | Servers / members / channels / roles  |
| GET    | `/api/features`                        | Tickets, giveaways, warnings counters |
| GET    | `/api/services`                        | API / MongoDB / GitHub / UptimeRobot  |
| GET    | `/api/chart/<metric>`                  | Time-series for members/commands/servers/cpu/ram |
| GET    | `/api/blacklist`                       | Paginated + searchable blacklist      |
| POST   | `/api/blacklist`                       | Add a user to the blacklist           |
| DELETE | `/api/blacklist/<user_id>`             | Remove a user from the blacklist      |
| GET    | `/api/tickets`                         | List tickets (open/closed/all)        |
| POST   | `/api/tickets/<id>/claim`              | Claim a ticket                        |
| POST   | `/api/tickets/<id>/close`              | Close a ticket                        |
| GET    | `/api/tickets/<id>/transcript`         | Fetch ticket transcript               |
| GET    | `/api/giveaways`                       | List giveaways (running/ended/all)    |
| POST   | `/api/giveaways/<id>/end`              | Force-end a giveaway                  |
| POST   | `/api/giveaways/<id>/reroll`           | Reroll giveaway winner(s)             |
| GET    | `/api/logs`                            | Paginated logs by category            |
| GET    | `/api/settings`                        | Current bot configuration             |
| POST   | `/api/settings`                        | Save bot configuration                |
| GET    | `/api/ping`                            | API healthcheck                       |

---

## 🎨 Design System

| Token             | Value                          |
|--------------------|---------------------------------|
| Font               | Inter (300–900)                |
| Background         | `#0a0b10` with radial gradients |
| Accent Blue        | `#5865F2`                      |
| Accent Purple      | `#9B59F6`                      |
| Card radius        | 22px (`--radius-lg`)           |
| Card style         | Glassmorphism (blur + translucent border) |

---

## 🔒 Security Notes

- Change `SECRET_KEY`, `DASHBOARD_USERNAME`, and `DASHBOARD_PASSWORD` before
  deploying publicly.
- The default auth is a simple session cookie login — swap in Discord OAuth2
  (see Option C above) for real staff-permission enforcement in production.
- Put the dashboard behind HTTPS (e.g. via a reverse proxy like Nginx or a
  platform's built-in TLS) before exposing it to the internet.

---

## 📄 License

MIT — use this freely for your own bot's dashboard.
