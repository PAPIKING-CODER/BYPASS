/* =============================================================================
   charts.js
   -----------------------------------------------------------------------------
   Chart.js setup for the Dashboard Home analytics section:
     - Members Growth (line)
     - Commands Usage (bar)
     - Servers Growth (line)
     - CPU & RAM Usage (dual-line)

   All charts share a common dark, glassmorphism-matching theme derived from
   the CSS custom properties defined in style.css.
============================================================================= */

const DashboardCharts = {
    _charts: {},

    /* Shared Chart.js defaults matching the dashboard's dark theme */
    _theme() {
        const styles = getComputedStyle(document.documentElement);
        return {
            textColor: styles.getPropertyValue("--text-secondary").trim() || "#A6A9B4",
            gridColor: "rgba(255,255,255,0.06)",
            blue: styles.getPropertyValue("--accent-blue").trim() || "#5865F2",
            blueLight: styles.getPropertyValue("--accent-blue-light").trim() || "#7289FF",
            purple: styles.getPropertyValue("--accent-purple").trim() || "#9B59F6",
            purpleLight: styles.getPropertyValue("--accent-purple-light").trim() || "#B685FF",
        };
    },

    _makeGradient(ctx, colorFrom, colorTo) {
        const gradient = ctx.createLinearGradient(0, 0, 0, 260);
        gradient.addColorStop(0, colorFrom);
        gradient.addColorStop(1, colorTo);
        return gradient;
    },

    _baseOptions(theme) {
        return {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: "index", intersect: false },
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: "rgba(21,22,31,0.95)",
                    borderColor: "rgba(255,255,255,0.1)",
                    borderWidth: 1,
                    titleColor: "#F2F3F5",
                    bodyColor: "#A6A9B4",
                    padding: 12,
                    cornerRadius: 10,
                    displayColors: true,
                    boxPadding: 4,
                },
            },
            scales: {
                x: {
                    grid: { display: false, drawBorder: false },
                    ticks: { color: theme.textColor, font: { family: "Inter", size: 11 }, maxRotation: 0 },
                },
                y: {
                    grid: { color: theme.gridColor, drawBorder: false },
                    ticks: { color: theme.textColor, font: { family: "Inter", size: 11 } },
                    beginAtZero: true,
                },
            },
        };
    },

    /**
     * Fetches /api/chart/<metric> and renders (or updates) the chart bound
     * to canvasId using the provided Chart.js dataset config factory.
     */
    async _renderChart(canvasId, metric, buildDatasets) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return;

        let data;
        try {
            const res = await fetch(`/api/chart/${metric}?points=14`);
            data = await res.json();
        } catch (err) {
            console.error(`Failed to load chart data for ${metric}`, err);
            return;
        }

        const ctx = canvas.getContext("2d");
        const theme = this._theme();

        if (this._charts[canvasId]) {
            this._charts[canvasId].data.labels = data.labels;
            this._charts[canvasId].data.datasets = buildDatasets(ctx, theme, data);
            this._charts[canvasId].update();
            return;
        }

        this._charts[canvasId] = new Chart(ctx, {
            type: buildDatasets.chartType || "line",
            data: {
                labels: data.labels,
                datasets: buildDatasets(ctx, theme, data),
            },
            options: this._baseOptions(theme),
        });
    },

    /* ---------------------------------------------------------------- */
    initHomeCharts() {
        // Members Growth — smooth area line, blue gradient
        const membersBuilder = (ctx, theme, data) => [{
            label: "Members",
            data: data.values,
            borderColor: theme.blueLight,
            backgroundColor: this._makeGradient(ctx, "rgba(88,101,242,0.35)", "rgba(88,101,242,0.02)"),
            fill: true,
            tension: 0.4,
            pointRadius: 0,
            pointHoverRadius: 5,
            borderWidth: 2.5,
        }];
        membersBuilder.chartType = "line";
        this._renderChart("chart-members", "members", membersBuilder);

        // Commands Usage — bar chart, purple gradient (rendered via its own
        // path below since Chart.js bar/line configs diverge structurally)
        this._renderBarChart("chart-commands", "commands");

        // Servers Growth — smooth area line, purple gradient
        const serversBuilder = (ctx, theme, data) => [{
            label: "Servers",
            data: data.values,
            borderColor: theme.purpleLight,
            backgroundColor: this._makeGradient(ctx, "rgba(155,89,246,0.35)", "rgba(155,89,246,0.02)"),
            fill: true,
            tension: 0.4,
            pointRadius: 0,
            pointHoverRadius: 5,
            borderWidth: 2.5,
        }];
        serversBuilder.chartType = "line";
        this._renderChart("chart-servers", "servers", serversBuilder);

        // CPU & RAM — dual line combo
        this._renderCpuRamChart();

        // Auto-refresh chart data every 60s to stay in sync with system load
        setInterval(() => {
            this._renderChart("chart-members", "members", membersBuilder);
            this._renderBarChart("chart-commands", "commands");
            this._renderChart("chart-servers", "servers", serversBuilder);
            this._renderCpuRamChart();
        }, 60000);
    },

    /* Bar chart needs its own render path because Chart.js type differs */
    async _renderBarChart(canvasId, metric) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return;

        let data;
        try {
            const res = await fetch(`/api/chart/${metric}?points=14`);
            data = await res.json();
        } catch (err) {
            console.error(err);
            return;
        }

        const ctx = canvas.getContext("2d");
        const theme = this._theme();

        if (this._charts[canvasId]) {
            this._charts[canvasId].data.labels = data.labels;
            this._charts[canvasId].data.datasets[0].data = data.values;
            this._charts[canvasId].update();
            return;
        }

        this._charts[canvasId] = new Chart(ctx, {
            type: "bar",
            data: {
                labels: data.labels,
                datasets: [{
                    label: "Commands Used",
                    data: data.values,
                    backgroundColor: this._makeGradient(ctx, theme.purpleLight, theme.purple),
                    borderRadius: 8,
                    maxBarThickness: 26,
                }],
            },
            options: this._baseOptions(theme),
        });
    },

    /* CPU + RAM combined dual-line chart */
    async _renderCpuRamChart() {
        const canvas = document.getElementById("chart-resources");
        if (!canvas) return;

        let cpuData, ramData;
        try {
            [cpuData, ramData] = await Promise.all([
                fetch("/api/chart/cpu?points=14").then((r) => r.json()),
                fetch("/api/chart/ram?points=14").then((r) => r.json()),
            ]);
        } catch (err) {
            console.error(err);
            return;
        }

        const ctx = canvas.getContext("2d");
        const theme = this._theme();

        const datasets = [
            {
                label: "CPU %",
                data: cpuData.values,
                borderColor: theme.blueLight,
                backgroundColor: "transparent",
                tension: 0.4,
                pointRadius: 0,
                pointHoverRadius: 5,
                borderWidth: 2.5,
            },
            {
                label: "RAM %",
                data: ramData.values,
                borderColor: theme.purpleLight,
                backgroundColor: "transparent",
                tension: 0.4,
                pointRadius: 0,
                pointHoverRadius: 5,
                borderWidth: 2.5,
                borderDash: [5, 4],
            },
        ];

        if (this._charts["chart-resources"]) {
            this._charts["chart-resources"].data.labels = cpuData.labels;
            this._charts["chart-resources"].data.datasets = datasets;
            this._charts["chart-resources"].update();
            return;
        }

        const options = this._baseOptions(theme);
        options.plugins.legend = {
            display: true,
            position: "top",
            align: "end",
            labels: { color: theme.textColor, font: { family: "Inter", size: 11 }, boxWidth: 12, usePointStyle: true },
        };

        this._charts["chart-resources"] = new Chart(ctx, {
            type: "line",
            data: { labels: cpuData.labels, datasets },
            options,
        });
    },
};
