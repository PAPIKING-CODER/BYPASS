/* =============================================================================
   dashboard.js
   -----------------------------------------------------------------------------
   Core client-side logic for the Discord Bot Dashboard:
     - Loading screen orchestration
     - Responsive sidebar toggle
     - Toast notification system
     - Small API helper (fetch wrapper)
     - Page controllers: Dashboard (home), SettingsPage, BlacklistPage,
       TicketsPage, GiveawaysPage, LogsPage

   All page controllers are IIFE-style singletons exposed on `window` so the
   relevant template can call `<Controller>.init()` after DOM ready.
============================================================================= */

/* ---------------------------------------------------------------------------
   API HELPER
--------------------------------------------------------------------------- */
const Api = {
    async get(url) {
        const res = await fetch(url, { headers: { Accept: "application/json" } });
        if (!res.ok) throw new Error(`GET ${url} failed (${res.status})`);
        return res.json();
    },
    async post(url, body) {
        const res = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json", Accept: "application/json" },
            body: JSON.stringify(body || {}),
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.error || `POST ${url} failed (${res.status})`);
        return data;
    },
    async delete(url) {
        const res = await fetch(url, { method: "DELETE", headers: { Accept: "application/json" } });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.error || `DELETE ${url} failed (${res.status})`);
        return data;
    },
};

/* ---------------------------------------------------------------------------
   TOAST NOTIFICATIONS
--------------------------------------------------------------------------- */
const Toast = {
    icons: {
        success: "fa-circle-check",
        danger: "fa-circle-exclamation",
        info: "fa-circle-info",
        warning: "fa-triangle-exclamation",
    },
    show(message, type = "info", title = null) {
        const container = document.getElementById("toast-container");
        if (!container) return;

        const defaultTitles = { success: "Success", danger: "Error", info: "Notice", warning: "Warning" };
        const el = document.createElement("div");
        el.className = `toast-glass ${type}`;
        el.innerHTML = `
            <i class="fa-solid ${this.icons[type] || this.icons.info}"></i>
            <div class="toast-body">
                <strong>${title || defaultTitles[type] || "Notice"}</strong>
                <span>${message}</span>
            </div>
        `;
        container.appendChild(el);
        setTimeout(() => el.remove(), 5100);

        this._bumpBell();
    },
    _bumpBell() {
        const count = document.getElementById("notif-count");
        if (!count) return;
        const current = parseInt(count.textContent || "0", 10) + 1;
        count.textContent = current;
        count.classList.remove("d-none");
    },
};

/* ---------------------------------------------------------------------------
   LOADING SCREEN
--------------------------------------------------------------------------- */
const LoadingScreen = {
    hide() {
        const el = document.getElementById("loading-screen");
        if (el) el.classList.add("hidden");
    },
};

/* ---------------------------------------------------------------------------
   SIDEBAR (responsive open/close for tablet & mobile)
--------------------------------------------------------------------------- */
const SidebarController = {
    init() {
        const sidebar = document.getElementById("sidebar");
        const overlay = document.getElementById("sidebar-overlay");
        const toggleBtn = document.getElementById("sidebar-toggle");
        const closeBtn = document.getElementById("sidebar-close");

        const open = () => { sidebar.classList.add("open"); overlay.classList.add("active"); };
        const close = () => { sidebar.classList.remove("open"); overlay.classList.remove("active"); };

        toggleBtn && toggleBtn.addEventListener("click", open);
        closeBtn && closeBtn.addEventListener("click", close);
        overlay && overlay.addEventListener("click", close);

        // "Coming soon" nav items — fully functional feedback, not a dead link
        document.querySelectorAll("[data-coming-soon]").forEach((link) => {
            link.addEventListener("click", (e) => {
                e.preventDefault();
                Toast.show(`${link.dataset.comingSoon} management is coming in a future update.`, "info", "Coming Soon");
            });
        });

        const aboutLink = document.getElementById("about-link");
        aboutLink && aboutLink.addEventListener("click", (e) => {
            e.preventDefault();
            Toast.show("A full-featured Discord bot control panel built with Flask, Bootstrap 5, and Chart.js.", "info", "About this Dashboard");
        });
    },
};

/* ---------------------------------------------------------------------------
   COUNTER ANIMATION — animates .counter elements from 0 to data-target
--------------------------------------------------------------------------- */
function animateCounter(el, targetValue, duration = 900) {
    const start = parseInt(el.dataset.current || "0", 10);
    const target = Math.round(targetValue);
    if (start === target) return;

    const startTime = performance.now();
    function tick(now) {
        const progress = Math.min((now - startTime) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
        const value = Math.round(start + (target - start) * eased);
        el.textContent = value.toLocaleString();
        if (progress < 1) {
            requestAnimationFrame(tick);
        } else {
            el.dataset.current = target;
        }
    }
    requestAnimationFrame(tick);
}

/* ---------------------------------------------------------------------------
   SIDEBAR STATUS DOT (shared bot connection indicator)
--------------------------------------------------------------------------- */
function updateSidebarStatus(connected, statusLabel) {
    const dot = document.getElementById("sidebar-status-dot");
    const text = document.getElementById("sidebar-status-text");
    if (!dot || !text) return;

    dot.classList.remove("online", "offline", "idle");
    if (connected) {
        dot.classList.add(statusLabel === "idle" ? "idle" : "online");
        text.textContent = statusLabel ? statusLabel.charAt(0).toUpperCase() + statusLabel.slice(1) : "Online";
    } else {
        dot.classList.add("offline");
        text.textContent = "Offline";
    }
}

/* =============================================================================
   DASHBOARD HOME PAGE CONTROLLER
============================================================================= */
const Dashboard = {
    _pollHandle: null,
    _firstLoad: true,

    startOverviewPolling() {
        this._fetchOverview();
        this._pollHandle = setInterval(() => this._fetchOverview(), 10000);
    },

    async _fetchOverview() {
        try {
            const data = await Api.get("/api/overview");
            this._renderBotCard(data.bot);
            this._renderSystem(data.system);
            this._renderGuild(data.guild);
            this._renderFeatures(data.features);
            this._renderServices(data.services);

            if (this._firstLoad) {
                LoadingScreen.hide();
                this._firstLoad = false;
            }
        } catch (err) {
            console.error(err);
            if (this._firstLoad) {
                LoadingScreen.hide();
                this._firstLoad = false;
            }
            Toast.show("Could not reach the dashboard API. Retrying shortly...", "danger", "Connection Error");
        }
    },

    _renderBotCard(bot) {
        const avatar = document.getElementById("bot-avatar");
        if (avatar && bot.avatar_url) avatar.src = bot.avatar_url;

        const nameEl = document.getElementById("bot-name-display");
        if (nameEl) nameEl.textContent = bot.name;

        const ring = document.getElementById("avatar-status-ring");
        const pill = document.getElementById("bot-status-pill");
        const connected = bot.status !== "offline" && bot.connected;

        if (ring) {
            ring.classList.remove("online", "offline");
            ring.classList.add(connected ? "online" : "offline");
        }
        if (pill) {
            pill.innerHTML = `<span class="status-dot ${connected ? "online" : "offline"}"></span> ${connected ? "Online" : "Offline"}`;
        }

        document.getElementById("bot-ping").textContent = bot.ping ?? "--";
        document.getElementById("bot-uptime").textContent = bot.uptime ?? "--";
        document.getElementById("bot-version-display").textContent = bot.bot_version ?? "--";
        document.getElementById("discordpy-version").textContent = bot.discordpy_version ?? "--";

        document.getElementById("stat-latency").textContent = `${bot.ping ?? "--"} ms`;

        updateSidebarStatus(connected, bot.status);
    },

    _renderSystem(sys) {
        document.getElementById("python-version").textContent = sys.python_version;
        document.getElementById("os-info").textContent = sys.os;

        this._setBar("cpu", sys.cpu_percent);
        this._setBar("ram", sys.ram_percent);
        this._setBar("disk", sys.disk_percent);

        document.getElementById("ram-detail-text").textContent = `${sys.ram_used_gb} / ${sys.ram_total_gb} GB`;
        document.getElementById("disk-detail-text").textContent = `${sys.disk_used_gb} / ${sys.disk_total_gb} GB`;
    },

    _setBar(prefix, percent) {
        const bar = document.getElementById(`${prefix}-progress-bar`);
        const text = document.getElementById(`${prefix}-percent-text`);
        if (bar) bar.style.width = `${percent}%`;
        if (text) text.textContent = `${percent.toFixed(1)}%`;
    },

    _renderGuild(guild) {
        this._animate("stat-servers", guild.guild_count);
        this._animate("stat-members", guild.member_count);
        this._animate("stat-commands", guild.commands_today);
        const channelsEl = document.getElementById("feat-channels");
        if (channelsEl) channelsEl.textContent = guild.channel_count.toLocaleString();
    },

    _renderFeatures(features) {
        document.getElementById("feat-tickets-open").textContent = features.tickets_open;
        document.getElementById("feat-tickets-closed").textContent = features.tickets_closed;
        document.getElementById("feat-giveaways").textContent = features.giveaways_active;
        document.getElementById("feat-warnings").textContent = features.warnings_total;
        document.getElementById("feat-blacklist").textContent = features.blacklist_count;

        const navBadge = document.getElementById("nav-badge-tickets");
        if (navBadge) navBadge.textContent = features.tickets_open;
    },

    _renderServices(services) {
        Object.entries(services).forEach(([key, val]) => {
            const el = document.getElementById(`service-${key}`);
            if (!el) return;
            el.textContent = val.label;
            el.className = `service-badge ${val.status}`;
        });
    },

    _animate(id, target) {
        const el = document.getElementById(id);
        if (el) animateCounter(el, target);
    },
};

/* =============================================================================
   SETTINGS PAGE CONTROLLER
============================================================================= */
const SettingsPage = {
    async init() {
        await this._loadSettings();
        LoadingScreen.hide();
        this._bindColorPicker();
        this._bindForm();
    },

    async _loadSettings() {
        try {
            const s = await Api.get("/api/settings");
            document.getElementById("prefix").value = s.prefix;
            document.getElementById("embed_color").value = s.embed_color;
            document.getElementById("embed_color_picker").value = s.embed_color;
            document.getElementById("bot_status").value = s.bot_status;
            document.getElementById("activity_type").value = s.activity_type;
            document.getElementById("activity_text").value = s.activity_text;

            document.getElementById("welcome_enabled").checked = s.welcome_enabled;
            document.getElementById("welcome_channel").value = s.welcome_channel;
            document.getElementById("welcome_message").value = s.welcome_message;

            document.getElementById("leave_enabled").checked = s.leave_enabled;
            document.getElementById("leave_channel").value = s.leave_channel;
            document.getElementById("leave_message").value = s.leave_message;

            document.getElementById("auto_role_enabled").checked = s.auto_role_enabled;
            document.getElementById("auto_role_name").value = s.auto_role_name;

            document.getElementById("log_channel").value = s.log_channel;
            document.querySelectorAll("#log-events-group input[type=checkbox]").forEach((cb) => {
                cb.checked = s.log_events.includes(cb.value);
            });
        } catch (err) {
            Toast.show("Failed to load current settings.", "danger");
        }
    },

    _bindColorPicker() {
        const picker = document.getElementById("embed_color_picker");
        const text = document.getElementById("embed_color");
        picker.addEventListener("input", () => (text.value = picker.value));
        text.addEventListener("input", () => {
            if (/^#[0-9A-Fa-f]{6}$/.test(text.value)) picker.value = text.value;
        });
    },

    _bindForm() {
        const form = document.getElementById("settings-form");
        form.addEventListener("submit", async (e) => {
            e.preventDefault();
            const btn = document.getElementById("save-settings-btn");
            btn.disabled = true;
            btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Saving...';

            const payload = {
                prefix: document.getElementById("prefix").value,
                embed_color: document.getElementById("embed_color").value,
                bot_status: document.getElementById("bot_status").value,
                activity_type: document.getElementById("activity_type").value,
                activity_text: document.getElementById("activity_text").value,
                welcome_enabled: document.getElementById("welcome_enabled").checked,
                welcome_channel: document.getElementById("welcome_channel").value,
                welcome_message: document.getElementById("welcome_message").value,
                leave_enabled: document.getElementById("leave_enabled").checked,
                leave_channel: document.getElementById("leave_channel").value,
                leave_message: document.getElementById("leave_message").value,
                auto_role_enabled: document.getElementById("auto_role_enabled").checked,
                auto_role_name: document.getElementById("auto_role_name").value,
                log_channel: document.getElementById("log_channel").value,
                log_events: Array.from(document.querySelectorAll("#log-events-group input:checked")).map((cb) => cb.value),
            };

            try {
                await Api.post("/api/settings", payload);
                Toast.show("Bot configuration updated successfully.", "success", "Settings Saved");
                document.getElementById("save-status-text").textContent = "All changes saved.";
            } catch (err) {
                Toast.show(err.message, "danger", "Save Failed");
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Save Changes';
            }
        });
    },
};

/* =============================================================================
   BLACKLIST PAGE CONTROLLER
============================================================================= */
const BlacklistPage = {
    _page: 1,
    _search: "",

    async init() {
        await this._load();
        LoadingScreen.hide();
        this._bindAddForm();
        this._bindSearch();
    },

    async _load() {
        try {
            const url = `/api/blacklist?page=${this._page}&per_page=8&search=${encodeURIComponent(this._search)}`;
            const data = await Api.get(url);
            this._renderTable(data.entries);
            this._renderPagination(data.page, data.total_pages);
            document.getElementById("blacklist-total-count").textContent = data.total;
        } catch (err) {
            Toast.show("Failed to load blacklist.", "danger");
        }
    },

    _renderTable(entries) {
        const body = document.getElementById("blacklist-table-body");
        const emptyState = document.getElementById("blacklist-empty-state");
        body.innerHTML = "";

        if (!entries.length) {
            emptyState.classList.remove("d-none");
            return;
        }
        emptyState.classList.add("d-none");

        entries.forEach((entry) => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td><div class="user-cell"><i class="fa-solid fa-user-slash" style="color:var(--color-danger)"></i> ${this._escape(entry.username)}</div></td>
                <td class="mono">${entry.user_id}</td>
                <td>${this._escape(entry.reason)}</td>
                <td>${this._escape(entry.moderator)}</td>
                <td>${new Date(entry.added_at).toLocaleDateString()}</td>
                <td class="text-end">
                    <div class="row-actions">
                        <button class="btn-glass-sm danger" data-remove="${entry.user_id}"><i class="fa-solid fa-trash"></i> Remove</button>
                    </div>
                </td>
            `;
            body.appendChild(tr);
        });

        body.querySelectorAll("[data-remove]").forEach((btn) => {
            btn.addEventListener("click", () => this._remove(btn.dataset.remove));
        });
    },

    _renderPagination(page, totalPages) {
        const container = document.getElementById("blacklist-pagination");
        container.innerHTML = "";
        if (totalPages <= 1) return;

        const prev = document.createElement("button");
        prev.className = "page-btn";
        prev.innerHTML = '<i class="fa-solid fa-chevron-left"></i>';
        prev.disabled = page <= 1;
        prev.addEventListener("click", () => { this._page = page - 1; this._load(); });
        container.appendChild(prev);

        for (let i = 1; i <= totalPages; i++) {
            const btn = document.createElement("button");
            btn.className = `page-btn ${i === page ? "active" : ""}`;
            btn.textContent = i;
            btn.addEventListener("click", () => { this._page = i; this._load(); });
            container.appendChild(btn);
        }

        const next = document.createElement("button");
        next.className = "page-btn";
        next.innerHTML = '<i class="fa-solid fa-chevron-right"></i>';
        next.disabled = page >= totalPages;
        next.addEventListener("click", () => { this._page = page + 1; this._load(); });
        container.appendChild(next);
    },

    _bindAddForm() {
        const form = document.getElementById("add-blacklist-form");
        form.addEventListener("submit", async (e) => {
            e.preventDefault();
            const userId = document.getElementById("bl-user-id").value.trim();
            const username = document.getElementById("bl-username").value.trim();
            const reason = document.getElementById("bl-reason").value.trim();

            try {
                await Api.post("/api/blacklist", { user_id: userId, username, reason });
                Toast.show(`User ${userId} has been blacklisted.`, "success", "User Blacklisted");
                form.reset();
                this._page = 1;
                this._load();
            } catch (err) {
                Toast.show(err.message, "danger", "Failed to Add");
            }
        });
    },

    _bindSearch() {
        const input = document.getElementById("blacklist-search");
        let timeout;
        input.addEventListener("input", () => {
            clearTimeout(timeout);
            timeout = setTimeout(() => {
                this._search = input.value.trim();
                this._page = 1;
                this._load();
            }, 350);
        });
    },

    async _remove(userId) {
        if (!confirm(`Remove user ${userId} from the blacklist?`)) return;
        try {
            await Api.delete(`/api/blacklist/${userId}`);
            Toast.show(`User ${userId} removed from blacklist.`, "success");
            this._load();
        } catch (err) {
            Toast.show(err.message, "danger");
        }
    },

    _escape(str) {
        const div = document.createElement("div");
        div.textContent = str || "";
        return div.innerHTML;
    },
};

/* =============================================================================
   TICKETS PAGE CONTROLLER
============================================================================= */
const TicketsPage = {
    _status: "open",

    async init() {
        await this._load();
        LoadingScreen.hide();
        this._bindTabs();
        this._bindModal();
    },

    async _load() {
        try {
            const data = await Api.get(`/api/tickets?status=${this._status}`);
            document.getElementById("tickets-open-count").textContent = data.open_count;
            document.getElementById("tickets-closed-count").textContent = data.closed_count;
            this._render(data.tickets);
        } catch (err) {
            Toast.show("Failed to load tickets.", "danger");
        }
    },

    _render(tickets) {
        const body = document.getElementById("tickets-table-body");
        const emptyState = document.getElementById("tickets-empty-state");
        body.innerHTML = "";

        if (!tickets.length) {
            emptyState.classList.remove("d-none");
            return;
        }
        emptyState.classList.add("d-none");

        tickets.forEach((t) => {
            const tr = document.createElement("tr");
            const isOpen = t.status === "open";
            tr.innerHTML = `
                <td class="mono">#${t.id}</td>
                <td>${t.subject}</td>
                <td>${t.opened_by}</td>
                <td><span class="log-category-tag">${t.category}</span></td>
                <td>${t.claimed_by ? t.claimed_by : '<span class="text-muted">Unclaimed</span>'}</td>
                <td>${new Date(t.created_at).toLocaleString()}</td>
                <td class="text-end">
                    <div class="row-actions">
                        ${isOpen ? `<button class="btn-glass-sm" data-claim="${t.id}"><i class="fa-solid fa-hand"></i> Claim</button>` : ""}
                        ${isOpen ? `<button class="btn-glass-sm danger" data-close="${t.id}"><i class="fa-solid fa-lock"></i> Close</button>` : ""}
                        <button class="btn-glass-sm" data-transcript="${t.id}"><i class="fa-solid fa-file-lines"></i> Transcript</button>
                    </div>
                </td>
            `;
            body.appendChild(tr);
        });

        body.querySelectorAll("[data-claim]").forEach((btn) => btn.addEventListener("click", () => this._claim(btn.dataset.claim)));
        body.querySelectorAll("[data-close]").forEach((btn) => btn.addEventListener("click", () => this._close(btn.dataset.close)));
        body.querySelectorAll("[data-transcript]").forEach((btn) => btn.addEventListener("click", () => this._openTranscript(btn.dataset.transcript)));
    },

    _bindTabs() {
        document.querySelectorAll("#ticket-tabs .tab-btn").forEach((btn) => {
            btn.addEventListener("click", () => {
                document.querySelectorAll("#ticket-tabs .tab-btn").forEach((b) => b.classList.remove("active"));
                btn.classList.add("active");
                this._status = btn.dataset.status;
                this._load();
            });
        });
    },

    async _claim(id) {
        const staffName = prompt("Claim this ticket as:", "staff_member");
        if (!staffName) return;
        try {
            await Api.post(`/api/tickets/${id}/claim`, { staff_name: staffName });
            Toast.show(`Ticket #${id} claimed.`, "success");
            this._load();
        } catch (err) {
            Toast.show(err.message, "danger");
        }
    },

    async _close(id) {
        if (!confirm(`Close ticket #${id}?`)) return;
        try {
            await Api.post(`/api/tickets/${id}/close`);
            Toast.show(`Ticket #${id} closed.`, "success");
            this._load();
        } catch (err) {
            Toast.show(err.message, "danger");
        }
    },

    async _openTranscript(id) {
        try {
            const data = await Api.get(`/api/tickets/${id}/transcript`);
            document.getElementById("transcript-modal-title").innerHTML =
                `<i class="fa-solid fa-file-lines icon-blue"></i> Transcript — ${data.subject}`;
            const bodyEl = document.getElementById("transcript-modal-body");
            bodyEl.innerHTML = data.messages
                .map((m) => `
                    <div class="transcript-message">
                        <span class="transcript-author">${m.author}</span>
                        <span class="transcript-time">${new Date(m.timestamp).toLocaleString()}</span>
                        <div>${m.content}</div>
                    </div>
                `)
                .join("");
            document.getElementById("transcript-modal-backdrop").classList.add("active");
        } catch (err) {
            Toast.show(err.message, "danger");
        }
    },

    _bindModal() {
        const backdrop = document.getElementById("transcript-modal-backdrop");
        document.getElementById("transcript-modal-close").addEventListener("click", () => backdrop.classList.remove("active"));
        backdrop.addEventListener("click", (e) => { if (e.target === backdrop) backdrop.classList.remove("active"); });
    },
};

/* =============================================================================
   GIVEAWAYS PAGE CONTROLLER
============================================================================= */
const GiveawaysPage = {
    _status: "running",

    async init() {
        await this._load();
        LoadingScreen.hide();
        this._bindTabs();
    },

    async _load() {
        try {
            const data = await Api.get(`/api/giveaways?status=${this._status}`);
            document.getElementById("giveaways-running-count").textContent = data.running_count;
            document.getElementById("giveaways-ended-count").textContent = data.ended_count;
            this._render(data.giveaways);
        } catch (err) {
            Toast.show("Failed to load giveaways.", "danger");
        }
    },

    _render(giveaways) {
        const grid = document.getElementById("giveaway-grid");
        const emptyState = document.getElementById("giveaways-empty-state");
        grid.innerHTML = "";

        if (!giveaways.length) {
            emptyState.classList.remove("d-none");
            return;
        }
        emptyState.classList.add("d-none");

        giveaways.forEach((g) => {
            const isRunning = g.status === "running";
            const card = document.createElement("div");
            card.className = "giveaway-card";
            card.innerHTML = `
                <div class="giveaway-card-header">
                    <span class="giveaway-prize"><i class="fa-solid fa-gift" style="color:var(--accent-purple-light)"></i> ${g.prize}</span>
                    <span class="status-badge ${g.status}">${isRunning ? "Running" : "Ended"}</span>
                </div>
                <div class="giveaway-meta">
                    <span><i class="fa-solid fa-user"></i> Hosted by ${g.host}</span>
                    <span><i class="fa-solid fa-users"></i> ${g.entrants} entrants</span>
                    <span><i class="fa-solid fa-trophy"></i> ${g.winners_count} winner(s)</span>
                    <span><i class="fa-solid fa-clock"></i> ${isRunning ? "Ends" : "Ended"} ${new Date(g.ends_at).toLocaleString()}</span>
                </div>
                ${g.winners.length ? `<div class="giveaway-winners"><i class="fa-solid fa-crown"></i> Winner(s): ${g.winners.join(", ")}</div>` : ""}
                <div class="giveaway-actions">
                    ${isRunning ? `<button class="btn-glass-sm danger" data-end="${g.id}"><i class="fa-solid fa-flag-checkered"></i> End Now</button>` : ""}
                    ${!isRunning ? `<button class="btn-glass-sm" data-reroll="${g.id}"><i class="fa-solid fa-shuffle"></i> Reroll</button>` : ""}
                </div>
            `;
            grid.appendChild(card);
        });

        grid.querySelectorAll("[data-end]").forEach((btn) => btn.addEventListener("click", () => this._end(btn.dataset.end)));
        grid.querySelectorAll("[data-reroll]").forEach((btn) => btn.addEventListener("click", () => this._reroll(btn.dataset.reroll)));
    },

    _bindTabs() {
        document.querySelectorAll("#giveaway-tabs .tab-btn").forEach((btn) => {
            btn.addEventListener("click", () => {
                document.querySelectorAll("#giveaway-tabs .tab-btn").forEach((b) => b.classList.remove("active"));
                btn.classList.add("active");
                this._status = btn.dataset.status;
                this._load();
            });
        });
    },

    async _end(id) {
        if (!confirm("End this giveaway now and draw winners?")) return;
        try {
            const res = await Api.post(`/api/giveaways/${id}/end`);
            Toast.show(`Giveaway #${id} ended. Winner(s): ${res.giveaway.winners.join(", ")}`, "success");
            this._load();
        } catch (err) {
            Toast.show(err.message, "danger");
        }
    },

    async _reroll(id) {
        try {
            const res = await Api.post(`/api/giveaways/${id}/reroll`);
            Toast.show(`Giveaway #${id} rerolled. New winner(s): ${res.giveaway.winners.join(", ")}`, "success");
            this._load();
        } catch (err) {
            Toast.show(err.message, "danger");
        }
    },
};

/* =============================================================================
   LOGS PAGE CONTROLLER
============================================================================= */
const LogsPage = {
    _category: "all",
    _page: 1,

    async init() {
        await this._load();
        LoadingScreen.hide();
        this._bindTabs();
    },

    async _load() {
        try {
            const data = await Api.get(`/api/logs?category=${this._category}&page=${this._page}&per_page=10`);
            this._render(data.logs);
            this._renderCounts(data.counts, data.total);
            this._renderPagination(data.page, data.total_pages);
        } catch (err) {
            Toast.show("Failed to load logs.", "danger");
        }
    },

    _render(logs) {
        const list = document.getElementById("log-list");
        const emptyState = document.getElementById("logs-empty-state");
        list.innerHTML = "";

        if (!logs.length) {
            emptyState.classList.remove("d-none");
            return;
        }
        emptyState.classList.add("d-none");

        const iconMap = { info: "fa-circle-info", warning: "fa-triangle-exclamation", error: "fa-circle-exclamation" };

        logs.forEach((log) => {
            const entry = document.createElement("div");
            entry.className = `log-entry level-${log.level}`;
            entry.innerHTML = `
                <i class="fa-solid ${iconMap[log.level] || "fa-circle-info"} log-entry-icon"></i>
                <div class="log-entry-body">
                    <div class="log-entry-message">${log.message}</div>
                    <div class="log-entry-meta">
                        <span class="log-category-tag">${log.category}</span>
                        <span>${new Date(log.timestamp).toLocaleString()}</span>
                    </div>
                </div>
            `;
            list.appendChild(entry);
        });
    },

    _renderCounts(counts, total) {
        document.getElementById("count-all").textContent = total >= 0 ? Object.values(counts).reduce((a, b) => a + b, 0) : 0;
        Object.entries(counts).forEach(([cat, count]) => {
            const el = document.getElementById(`count-${cat}`);
            if (el) el.textContent = count;
        });
    },

    _renderPagination(page, totalPages) {
        const container = document.getElementById("logs-pagination");
        container.innerHTML = "";
        if (totalPages <= 1) return;

        for (let i = 1; i <= totalPages; i++) {
            const btn = document.createElement("button");
            btn.className = `page-btn ${i === page ? "active" : ""}`;
            btn.textContent = i;
            btn.addEventListener("click", () => { this._page = i; this._load(); });
            container.appendChild(btn);
        }
    },

    _bindTabs() {
        document.querySelectorAll("#log-tabs .tab-btn").forEach((btn) => {
            btn.addEventListener("click", () => {
                document.querySelectorAll("#log-tabs .tab-btn").forEach((b) => b.classList.remove("active"));
                btn.classList.add("active");
                this._category = btn.dataset.category;
                this._page = 1;
                this._load();
            });
        });
    },
};

/* ---------------------------------------------------------------------------
   BOOTSTRAP — runs on every page
--------------------------------------------------------------------------- */
document.addEventListener("DOMContentLoaded", () => {
    SidebarController.init();

    // Fallback: hide loading screen after 4s even if a page controller
    // forgets to call LoadingScreen.hide() (e.g. static pages).
    setTimeout(() => LoadingScreen.hide(), 4000);
});
