"""
api/settings.py
-----------------------------------------------------------------------------
REST API blueprint for the Settings page: prefix, embed color, bot status
& activity, welcome/leave messages, auto-role, and logging channel config.

TODO (integration): persist this document to the same MongoDB collection
your bot reads its guild configuration from (typically one document per
guild id, keyed as `guild_config`). The bot should then either poll this
collection or subscribe to a MongoDB change stream so updates saved here
take effect immediately without a bot restart.
-----------------------------------------------------------------------------
"""

from flask import Blueprint, jsonify, request

settings_bp = Blueprint("settings_api", __name__, url_prefix="/api/settings")


class SettingsStore:
    """Placeholder single-guild settings store — see module docstring."""

    def __init__(self):
        self._settings = {
            "prefix": "!",
            "embed_color": "#5865F2",
            "bot_status": "online",          # online | idle | dnd | invisible
            "activity_type": "playing",       # playing | listening | watching | competing
            "activity_text": "with the dashboard",
            "welcome_enabled": True,
            "welcome_channel": "welcome",
            "welcome_message": "Welcome to the server, {user}! 🎉",
            "leave_enabled": True,
            "leave_channel": "general",
            "leave_message": "{user} has left the server. 👋",
            "auto_role_enabled": False,
            "auto_role_name": "Member",
            "log_channel": "mod-logs",
            "log_events": ["ban", "kick", "warn", "message_delete"],
        }

    def get(self):
        return dict(self._settings)

    def update(self, payload):
        allowed_keys = set(self._settings.keys())
        for key, value in payload.items():
            if key in allowed_keys:
                self._settings[key] = value
        return self.get()


_store = SettingsStore()

_VALID_STATUSES = {"online", "idle", "dnd", "invisible"}
_VALID_ACTIVITIES = {"playing", "listening", "watching", "competing"}


@settings_bp.route("", methods=["GET"])
def get_settings():
    """Return the current bot configuration."""
    return jsonify(_store.get())


@settings_bp.route("", methods=["POST"])
def save_settings():
    """Persist updated bot configuration.

    Accepts a partial or full JSON body; only recognised keys are applied.
    Performs basic validation on constrained fields.
    """
    data = request.get_json(silent=True) or {}

    if "bot_status" in data and data["bot_status"] not in _VALID_STATUSES:
        return jsonify({"error": f"bot_status must be one of {sorted(_VALID_STATUSES)}"}), 400

    if "activity_type" in data and data["activity_type"] not in _VALID_ACTIVITIES:
        return jsonify({"error": f"activity_type must be one of {sorted(_VALID_ACTIVITIES)}"}), 400

    if "embed_color" in data:
        color = str(data["embed_color"]).strip()
        if not color.startswith("#") or len(color) not in (4, 7):
            return jsonify({"error": "embed_color must be a valid hex color, e.g. #5865F2"}), 400

    if "prefix" in data and (not data["prefix"] or len(str(data["prefix"])) > 5):
        return jsonify({"error": "prefix must be 1-5 characters"}), 400

    updated = _store.update(data)
    return jsonify({"message": "Settings saved successfully", "settings": updated})
