"""
api package
-----------------------------------------------------------------------------
Contains the REST API blueprint(s) and the bot-data integration layer used
by the Discord Bot Dashboard.
-----------------------------------------------------------------------------
"""
