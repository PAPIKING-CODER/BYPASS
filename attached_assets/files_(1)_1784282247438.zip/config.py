"""
config.py
-----------------------------------------------------------------------------
Central configuration for the Discord Bot Dashboard (Flask application).

All environment-dependent values (secrets, database URIs, bot integration
paths, etc.) are read from environment variables so the same codebase can be
deployed to development, staging, and production without code changes.

Usage:
    from config import Config
    app.config.from_object(Config)
-----------------------------------------------------------------------------
"""

import os
from datetime import timedelta


class Config:
    """Base configuration shared across all environments."""

    # ---------------------------------------------------------------------
    # Flask core settings
    # ---------------------------------------------------------------------
    SECRET_KEY = os.environ.get("SECRET_KEY", "change-this-secret-key-in-production")
    DEBUG = os.environ.get("FLASK_DEBUG", "False").lower() == "true"
    JSON_SORT_KEYS = False  # Preserve key order in returned JSON payloads

    # Session lifetime for logged-in dashboard admins
    PERMANENT_SESSION_LIFETIME = timedelta(hours=12)

    # ---------------------------------------------------------------------
    # Dashboard authentication
    # ---------------------------------------------------------------------
    # Simple username/password auth for the dashboard admin panel.
    # In production this should be replaced with Discord OAuth2 or a proper
    # user/permissions table backed by a database.
    DASHBOARD_USERNAME = os.environ.get("DASHBOARD_USERNAME", "admin")
    DASHBOARD_PASSWORD = os.environ.get("DASHBOARD_PASSWORD", "admin123")

    # Discord OAuth2 (optional - ready for future integration)
    DISCORD_CLIENT_ID = os.environ.get("DISCORD_CLIENT_ID", "")
    DISCORD_CLIENT_SECRET = os.environ.get("DISCORD_CLIENT_SECRET", "")
    DISCORD_REDIRECT_URI = os.environ.get("DISCORD_REDIRECT_URI", "http://localhost:5000/callback")
    DISCORD_API_BASE_URL = "https://discord.com/api/v10"

    # ---------------------------------------------------------------------
    # Bot integration settings
    # ---------------------------------------------------------------------
    # Path to the IPC file / socket the running Discord bot writes live
    # stats to. The dashboard reads this file (or queries the bot's IPC
    # server) to display real-time information. See api/stats.py for the
    # full integration layer and fallback placeholder logic.
    BOT_STATS_FILE = os.environ.get("BOT_STATS_FILE", "bot_stats.json")
    BOT_IPC_HOST = os.environ.get("BOT_IPC_HOST", "127.0.0.1")
    BOT_IPC_PORT = int(os.environ.get("BOT_IPC_PORT", 8765))

    BOT_NAME = os.environ.get("BOT_NAME", "AtlasBot")
    BOT_VERSION = os.environ.get("BOT_VERSION", "2.4.1")
    BOT_AVATAR_URL = os.environ.get(
        "BOT_AVATAR_URL",
        "https://cdn.discordapp.com/embed/avatars/0.png",
    )
    BOT_INVITE_URL = os.environ.get("BOT_INVITE_URL", "#")
    SUPPORT_SERVER_URL = os.environ.get("SUPPORT_SERVER_URL", "#")
    GITHUB_REPO_URL = os.environ.get("GITHUB_REPO_URL", "https://github.com/yourname/discord-bot")
    DEVELOPER_NAME = os.environ.get("DEVELOPER_NAME", "YourName")

    # ---------------------------------------------------------------------
    # Database (MongoDB) — used both by the bot and the dashboard
    # ---------------------------------------------------------------------
    MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017")
    MONGO_DB_NAME = os.environ.get("MONGO_DB_NAME", "discord_bot")

    # ---------------------------------------------------------------------
    # External monitoring services
    # ---------------------------------------------------------------------
    UPTIME_ROBOT_API_KEY = os.environ.get("UPTIME_ROBOT_API_KEY", "")
    UPTIME_ROBOT_MONITOR_ID = os.environ.get("UPTIME_ROBOT_MONITOR_ID", "")

    # ---------------------------------------------------------------------
    # Pagination defaults
    # ---------------------------------------------------------------------
    ITEMS_PER_PAGE = int(os.environ.get("ITEMS_PER_PAGE", 10))


class DevelopmentConfig(Config):
    DEBUG = True


class ProductionConfig(Config):
    DEBUG = False


# Map string names (from FLASK_ENV) to config classes
config_by_name = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
    "default": DevelopmentConfig,
}
