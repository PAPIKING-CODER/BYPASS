"""
api/tickets.py
-----------------------------------------------------------------------------
REST API blueprint for the Tickets page: list open/closed tickets, claim a
ticket, close a ticket, and fetch a transcript.

TODO (integration): back TicketStore with the same ticket collection your
Discord.py ticket-system cog uses, so claiming/closing here immediately
reflects in the actual Discord channel (e.g. archive the channel, post a
"claimed by" embed, DM the transcript, etc.) via a shared MongoDB collection
or a direct IPC call to the bot process.
-----------------------------------------------------------------------------
"""

from datetime import datetime, timedelta

from flask import Blueprint, jsonify, request

tickets_bp = Blueprint("tickets_api", __name__, url_prefix="/api/tickets")


class TicketStore:
    """Placeholder ticket data store — see module docstring for integration."""

    def __init__(self):
        now = datetime.utcnow()
        self._tickets = [
            {
                "id": 101,
                "subject": "Cannot access premium role",
                "opened_by": "kayla.dev",
                "status": "open",
                "claimed_by": None,
                "category": "Support",
                "created_at": (now - timedelta(hours=3)).isoformat(),
                "closed_at": None,
            },
            {
                "id": 102,
                "subject": "Bot not responding to !play command",
                "opened_by": "musicfan22",
                "status": "open",
                "claimed_by": "staff_alex",
                "category": "Bug Report",
                "created_at": (now - timedelta(hours=8)).isoformat(),
                "closed_at": None,
            },
            {
                "id": 103,
                "subject": "Report: user harassment in #general",
                "opened_by": "moderatorwatch",
                "status": "open",
                "claimed_by": None,
                "category": "Report",
                "created_at": (now - timedelta(minutes=40)).isoformat(),
                "closed_at": None,
            },
            {
                "id": 98,
                "subject": "Partnership request",
                "opened_by": "server_owner_99",
                "status": "closed",
                "claimed_by": "staff_jane",
                "category": "Partnership",
                "created_at": (now - timedelta(days=3)).isoformat(),
                "closed_at": (now - timedelta(days=2)).isoformat(),
            },
            {
                "id": 95,
                "subject": "Refund question for premium sub",
                "opened_by": "billinguser",
                "status": "closed",
                "claimed_by": "staff_alex",
                "category": "Billing",
                "created_at": (now - timedelta(days=6)).isoformat(),
                "closed_at": (now - timedelta(days=6)).isoformat(),
            },
        ]

    def all(self):
        return sorted(self._tickets, key=lambda t: t["created_at"], reverse=True)

    def by_status(self, status):
        return [t for t in self.all() if t["status"] == status]

    def get(self, ticket_id):
        return next((t for t in self._tickets if t["id"] == ticket_id), None)

    def claim(self, ticket_id, staff_name):
        ticket = self.get(ticket_id)
        if not ticket:
            return None
        ticket["claimed_by"] = staff_name
        return ticket

    def close(self, ticket_id):
        ticket = self.get(ticket_id)
        if not ticket:
            return None
        ticket["status"] = "closed"
        ticket["closed_at"] = datetime.utcnow().isoformat()
        return ticket


_store = TicketStore()


@tickets_bp.route("", methods=["GET"])
def list_tickets():
    """List tickets, optionally filtered by status (open|closed)."""
    status = request.args.get("status", default="all", type=str)
    if status == "all":
        data = _store.all()
    elif status in ("open", "closed"):
        data = _store.by_status(status)
    else:
        return jsonify({"error": "status must be 'open', 'closed', or 'all'"}), 400

    return jsonify({
        "tickets": data,
        "open_count": len(_store.by_status("open")),
        "closed_count": len(_store.by_status("closed")),
    })


@tickets_bp.route("/<int:ticket_id>/claim", methods=["POST"])
def claim_ticket(ticket_id):
    """Assign the ticket to a staff member.

    Expected JSON body: { "staff_name": str }
    """
    data = request.get_json(silent=True) or {}
    staff_name = (data.get("staff_name") or "dashboard-staff").strip()

    ticket = _store.claim(ticket_id, staff_name)
    if not ticket:
        return jsonify({"error": "Ticket not found"}), 404
    return jsonify({"message": f"Ticket #{ticket_id} claimed by {staff_name}", "ticket": ticket})


@tickets_bp.route("/<int:ticket_id>/close", methods=["POST"])
def close_ticket(ticket_id):
    """Close an open ticket."""
    ticket = _store.close(ticket_id)
    if not ticket:
        return jsonify({"error": "Ticket not found"}), 404
    return jsonify({"message": f"Ticket #{ticket_id} closed", "ticket": ticket})


@tickets_bp.route("/<int:ticket_id>/transcript", methods=["GET"])
def get_transcript(ticket_id):
    """Fetch (or generate) the message transcript for a ticket.

    TODO (integration): pull the real message log the bot saved when the
    ticket channel was archived (commonly stored as HTML/plaintext in
    MongoDB/S3 alongside the ticket document).
    """
    ticket = _store.get(ticket_id)
    if not ticket:
        return jsonify({"error": "Ticket not found"}), 404

    # Placeholder transcript content, structured the way a real transcript
    # log would be so the frontend rendering code is already correct.
    transcript = [
        {"author": ticket["opened_by"], "timestamp": ticket["created_at"], "content": f"Hi, I need help with: {ticket['subject']}"},
        {"author": "System", "timestamp": ticket["created_at"], "content": f"Ticket #{ticket_id} opened in category '{ticket['category']}'."},
    ]
    if ticket["claimed_by"]:
        transcript.append({
            "author": "System",
            "timestamp": ticket["created_at"],
            "content": f"Ticket claimed by {ticket['claimed_by']}.",
        })
    if ticket["status"] == "closed":
        transcript.append({
            "author": "System",
            "timestamp": ticket["closed_at"],
            "content": "Ticket closed.",
        })

    return jsonify({"ticket_id": ticket_id, "subject": ticket["subject"], "messages": transcript})
