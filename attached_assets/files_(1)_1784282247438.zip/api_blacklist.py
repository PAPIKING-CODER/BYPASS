"""
api/blacklist.py
-----------------------------------------------------------------------------
REST API blueprint for the Blacklist page: add/remove/search blacklisted
users, with pagination.

Data layer
----------
In production this should read/write a MongoDB collection shared with the
bot process (so a blacklist entry added here instantly blocks the user in
Discord). Until that collection is wired up, an in-memory store seeded with
realistic sample data keeps the dashboard fully interactive and demo-ready.
Every function is written so swapping the storage backend only requires
editing `BlacklistStore`.
-----------------------------------------------------------------------------
"""

from datetime import datetime, timedelta

from flask import Blueprint, jsonify, request

blacklist_bp = Blueprint("blacklist_api", __name__, url_prefix="/api/blacklist")


class BlacklistStore:
    """In-memory blacklist store (placeholder for a MongoDB collection).

    TODO (integration): replace the methods below with pymongo calls, e.g.

        def add(self, user_id, username, reason, moderator):
            db.blacklist.insert_one({
                "user_id": user_id, "username": username,
                "reason": reason, "moderator": moderator,
                "added_at": datetime.utcnow(),
            })
    """

    def __init__(self):
        now = datetime.utcnow()
        self._entries = [
            {
                "id": 1,
                "user_id": "482910473820193284",
                "username": "toxicuser#0001",
                "reason": "Repeated raid attempts across multiple servers",
                "moderator": "admin",
                "added_at": (now - timedelta(days=12)).isoformat(),
            },
            {
                "id": 2,
                "user_id": "719283746192837465",
                "username": "spambot9000#4521",
                "reason": "Automated spam / self-bot detected",
                "moderator": "admin",
                "added_at": (now - timedelta(days=5)).isoformat(),
            },
            {
                "id": 3,
                "user_id": "928374651029384756",
                "username": "scammer_xyz#7712",
                "reason": "Nitro scam links distribution",
                "moderator": "moderator_jane",
                "added_at": (now - timedelta(days=2)).isoformat(),
            },
        ]
        self._next_id = 4

    def all(self):
        return list(reversed(self._entries))

    def search(self, query):
        query = query.lower().strip()
        if not query:
            return self.all()
        return [
            e for e in self.all()
            if query in e["username"].lower() or query in e["user_id"]
        ]

    def add(self, user_id, username, reason, moderator="dashboard"):
        entry = {
            "id": self._next_id,
            "user_id": user_id,
            "username": username or f"user#{user_id[-4:]}",
            "reason": reason or "No reason provided",
            "moderator": moderator,
            "added_at": datetime.utcnow().isoformat(),
        }
        self._entries.append(entry)
        self._next_id += 1
        return entry

    def remove(self, user_id):
        before = len(self._entries)
        self._entries = [e for e in self._entries if e["user_id"] != user_id]
        return len(self._entries) < before


# Module-level singleton store (swap for a DB-backed repository in prod)
_store = BlacklistStore()


@blacklist_bp.route("", methods=["GET"])
def list_blacklist():
    """Paginated + searchable blacklist listing.

    Query params:
        page (int, default 1)
        per_page (int, default 10)
        search (str, optional) — matches username or user id
    """
    page = request.args.get("page", default=1, type=int)
    per_page = request.args.get("per_page", default=10, type=int)
    search = request.args.get("search", default="", type=str)

    entries = _store.search(search) if search else _store.all()

    total = len(entries)
    start = (page - 1) * per_page
    end = start + per_page
    page_entries = entries[start:end]

    return jsonify({
        "entries": page_entries,
        "page": page,
        "per_page": per_page,
        "total": total,
        "total_pages": max(1, (total + per_page - 1) // per_page),
    })


@blacklist_bp.route("", methods=["POST"])
def add_to_blacklist():
    """Add a user to the blacklist.

    Expected JSON body: { "user_id": str, "username": str, "reason": str }
    """
    data = request.get_json(silent=True) or {}
    user_id = (data.get("user_id") or "").strip()
    reason = (data.get("reason") or "").strip()
    username = (data.get("username") or "").strip()

    if not user_id:
        return jsonify({"error": "user_id is required"}), 400
    if not user_id.isdigit():
        return jsonify({"error": "user_id must be a valid Discord snowflake (numeric)"}), 400

    entry = _store.add(user_id, username, reason)
    return jsonify({"message": "User added to blacklist", "entry": entry}), 201


@blacklist_bp.route("/<user_id>", methods=["DELETE"])
def remove_from_blacklist(user_id):
    """Remove a user from the blacklist by Discord user id."""
    removed = _store.remove(user_id)
    if not removed:
        return jsonify({"error": "User not found in blacklist"}), 404
    return jsonify({"message": "User removed from blacklist"})
